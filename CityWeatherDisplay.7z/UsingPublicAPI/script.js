let city = "Évora";

$.getJSON(
  "http://api.openweathermap.org/data/2.5/weather?q=" + city + "&?id=524901&APPID=07673139adeb014ed75cce1e7fd1453b",
  function(data) {
    //console.log(data);

    var icon = "http://openweathermap.org/img/w/" + data.weather[0].icon + ".png";
    var temp = Math.floor(data.main.temp);
    var weather = data.weather[0].main;

    //console.log(icon);

    $(".icon").attr("src", icon);
    $(".weather").append(weather);
    $(".temp").append(temp);
});
