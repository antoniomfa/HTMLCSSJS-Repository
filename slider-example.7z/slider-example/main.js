function disableBtn() {
  document.getElementById("toggle").disabled = true;
}

function enableBtn() {
  document.getElementById("toggle").disabled = false;
}

$("#toggle").click(function A() {
  $(".slide-in").toggleClass("show");
  disableBtn();
});

$("#x").click(function B() {
  $(".slide-in").toggleClass("show");
  enableBtn();
});



// $("#").attr("disabled", "disabled");

